<footer class="site-footer">
        <div class="text-center">
          <p>
            &copy; Copyrights <strong>Dashio</strong>. All Rights Reserved
          </p>
          <div class="credits">
            <!--
              You are NOT allowed to delete the credit link to TemplateMag with free version.
              You can delete the credit link only if you bought the pro version.
              Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
              Licensing information: https://templatemag.com/license/
            -->
            Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
          </div>
          <a href="index.html#" class="go-top">
            <i class="fa fa-angle-up"></i>
            </a>
        </div>
      </footer>