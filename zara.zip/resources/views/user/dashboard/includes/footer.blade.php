   <footer class="page-footer text-center">
               
          <div class="copywrite text-center" style="font-size: 12px;margin-top: 15px;>
            <div class="text-center"> <b style="font-size: 14px;"> Copyright &copy; <a href="https://www.creativepos.com.bd">Creative Pos</a>&nbsp; <?php echo date("Y") ?>.</b> <b style="font-size: 14px;">Develop by <a href="https://www.creativesoftware.com.bd">Creative Software</a>.</b>

      </div>
     </footer>