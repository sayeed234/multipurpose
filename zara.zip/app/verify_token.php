<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class verify_token extends Model
{
    //
}
